import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Employee} from './model/Employee'
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  constructor(private http:HttpClient) { }
  Dsa="http://10.113.113.44:7000/topics/1/scores";
  Angular='http://10.113.113.44:7000/topics/2/scores';
  Java='http://10.113.113.44:7000/topics/3/scores';
  React='http://10.113.113.44:7000/topics/4/scores';
  Docker='http://10.113.113.44:7000/topics/5/scores';
  topics="https://jsonplaceholder.typicode.com/posts";
  subj1="http://10.113.113.44:7000/topics/";
  subj2="/scores";
  finalUrl:any;

  // Docker="http://10.113.113.44:7000/topics/5/scores";
  // english="https://jsonplaceholder.typicode.com/posts";
  // science="https://jsonplaceholder.typicode.com/albums";
  getData(sub:string):Observable<Employee>{
    // this.finalUrl=this.subj1+sub+this.subj2;
    if(sub=='dsa'){return this.http.get<Employee>(this.finalUrl);}
    if(sub=='angular'){return this.http.get<Employee>(this.Angular);}
    if(sub=='java'){return this.http.get<Employee>(this.Java);}
    if(sub=='docker'){return this.http.get<Employee>(this.Docker);}
    return this.http.get<Employee>(this.React);
  }
  gettopics(){
    return this.http.get(this.topics);
  }
}
