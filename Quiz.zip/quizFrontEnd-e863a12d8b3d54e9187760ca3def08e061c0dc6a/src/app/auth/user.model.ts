export class User{
    constructor(public userEmail: string,
        public i){}
    
    
}