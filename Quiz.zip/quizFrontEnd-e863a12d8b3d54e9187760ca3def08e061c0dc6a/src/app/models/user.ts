export class User{
    fullName:string;
    
}